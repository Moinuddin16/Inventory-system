<?php
   
   class BrandConstant {
        const BRAND_TABLE = "brand";
        const BRAND_COLLUMN_ID = "Id";
        const BRAND_COLLUMN_NAME = "Name";
        const BRAND_COLLUMN_WEBSITE = "Website";
    }

?>
