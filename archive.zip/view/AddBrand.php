<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script type="text/javascript" src="..\Presenter\AddBrand.js"></script>
        <link rel="stylesheet" type="text/css" href="css\style_AddBrand.css">
    </head>
    <body>
        <div id="Add_Brand">
            <form action="Presenter\AddBrand.js" id="myForm ">
                Brand Name : 
                <input class="inputMod" type="text" name="name" placeholder="Brand Name"><br>
                Brand Website : 
                <input class="inputMod" type="text" name="website" placeholder="Brand Website"><br>
                <input type="submit" value="Submit">
            </form>
        </div>
    </body>
</html>
